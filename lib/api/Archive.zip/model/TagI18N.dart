/// A tag with internationalisation.
class TagI18N {
  String id;

  String textDE;
  String textEN;
  String textFR;

  TagI18N(this.id);

  //TODO: how to get the text (DE, EN, FR, ...) for the given id ?
}
